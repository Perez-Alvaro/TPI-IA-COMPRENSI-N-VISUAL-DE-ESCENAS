# Licencias y atribución

Este dataset utiliza imágenes distribuidas por COCO y anotaciones derivadas de LVIS v1 val.

Las imágenes conservan sus licencias originales. La licencia y la página de origen de cada archivo se encuentran en `attribution.csv`. El dataset completo se declara como `other` en Kaggle porque no corresponde asignar una única licencia a todas las imágenes.

Fuentes oficiales:

- LVIS: https://www.lvisdataset.org/
- COCO: https://cocodataset.org/

## Licencias presentes

| Licencia | Imágenes | URL |
|---|---:|---|
| Attribution License | 17 | http://creativecommons.org/licenses/by/2.0/ |
| Attribution-NoDerivs License | 9 | http://creativecommons.org/licenses/by-nd/2.0/ |
| Attribution-NonCommercial License | 14 | http://creativecommons.org/licenses/by-nc/2.0/ |
| Attribution-NonCommercial-NoDerivs License | 34 | http://creativecommons.org/licenses/by-nc-nd/2.0/ |
| Attribution-NonCommercial-ShareAlike License | 38 | http://creativecommons.org/licenses/by-nc-sa/2.0/ |
| Attribution-ShareAlike License | 8 | http://creativecommons.org/licenses/by-sa/2.0/ |
