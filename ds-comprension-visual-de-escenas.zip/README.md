# TPI 2026 — Comprensión visual

Dataset de imágenes para el Trabajo Práctico Integrador de comprensión visual de escenas.

## Contenido

- `120` imágenes en `images/`.
- `120` categorías evaluables.
- Bounding boxes y máscaras de instancia en `annotations.json`.
- Licencias y páginas de origen en `attribution.csv` y `LICENSES.md`.

## Formato

`annotations.json` utiliza la estructura COCO para segmentación de instancias:

- `images`: identificador, nombre de archivo, dimensiones y metadata LVIS de exhaustividad;
- `categories`: identificador y nombre de cada categoría;
- `annotations`: categoría, bounding box `xywh`, máscara, área e identificador de imagen.

Cada imagen incluye dos listas de IDs de categoría necesarias para evaluar detecciones:

- `neg_category_ids`: categorías verificadas como ausentes;
- `not_exhaustive_category_ids`: categorías presentes cuya anotación puede no incluir todas las instancias.

Una categoría con anotaciones es positiva. Si además figura como no exhaustiva, las detecciones adicionales no emparejadas deben ignorarse. Una categoría en `neg_category_ids` admite contar predicciones como falsos positivos. Para pares imagen-categoría que no son positivos ni negativos, la ausencia de anotaciones no prueba que el objeto no exista y las predicciones deben ignorarse.

## Fuentes

El dataset deriva de LVIS v1 val y utiliza imágenes de COCO. Consulte `LICENSES.md` antes de redistribuir o reutilizar los archivos.

## Citas

```bibtex
@inproceedings{gupta2019lvis,
  title={LVIS: A Dataset for Large Vocabulary Instance Segmentation},
  author={Gupta, Agrim and Dollar, Piotr and Girshick, Ross},
  booktitle={CVPR},
  year={2019}
}

@inproceedings{lin2014microsoft,
  title={Microsoft COCO: Common Objects in Context},
  author={Lin, Tsung-Yi and others},
  booktitle={ECCV},
  year={2014}
}
```
